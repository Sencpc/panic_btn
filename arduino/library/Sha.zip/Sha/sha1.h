#ifndef Sha1_h
#define Sha1_h

#include <inttypes.h>
#include "Print.h"

#define SHA1_HASH_LENGTH 20
#define SHA1_BLOCK_LENGTH 64

union _sha1_buffer {
  uint8_t b[SHA1_BLOCK_LENGTH];
  uint32_t w[SHA1_BLOCK_LENGTH/4];
};
union _sha1_state {
  uint8_t b[SHA1_HASH_LENGTH];
  uint32_t w[SHA1_HASH_LENGTH/4];
};

class Sha1Class : public Print
{
  public:
    void init(void);
    void initHmac(const uint8_t* secret, int secretLength);
    uint8_t* result(void);
    uint8_t* resultHmac(void);
    virtual size_t write(uint8_t);
    using Print::write;
  private:
    void pad();
    void addUncounted(uint8_t data);
    void hashBlock();
    uint32_t rol32(uint32_t number, uint8_t bits);
    _sha1_buffer buffer;
    uint8_t bufferOffset;
    _sha1_state state;
    uint32_t byteCount;
    uint8_t keyBuffer[SHA1_BLOCK_LENGTH];
    uint8_t innerHash[SHA1_HASH_LENGTH];
    
};
extern Sha1Class Sha1;

#endif
